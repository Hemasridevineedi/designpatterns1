package abstractfactory_pattern;

public interface Shape {
	void draw();
}
