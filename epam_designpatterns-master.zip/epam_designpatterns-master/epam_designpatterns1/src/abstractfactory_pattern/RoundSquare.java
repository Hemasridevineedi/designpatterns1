package abstractfactory_pattern;

public class RoundSquare implements Shape{
	public void draw() {
	      System.out.println("Inside RoundedSquare::draw() method.");
	   }
}
