package command_pattern;

public interface Order {
	 void execute();
}
